import React from 'react';
import { ProjectOwnerSwipe } from '@/components/swipe/ProjectOwnerSwipe';

export function SearchTalents() {
  return <ProjectOwnerSwipe />;
}