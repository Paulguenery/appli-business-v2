import React from 'react';
import { ProjectSeekerSwipe } from '@/components/swipe/ProjectSeekerSwipe';

export function SearchProjects() {
  return <ProjectSeekerSwipe />;
}