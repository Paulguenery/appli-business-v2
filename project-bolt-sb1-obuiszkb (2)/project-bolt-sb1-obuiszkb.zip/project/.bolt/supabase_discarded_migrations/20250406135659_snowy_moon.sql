/*
  # Create admin test account

  1. Changes
    - Create admin user with valid test email
    - Create both project owner and seeker profiles for admin
  
  2. Security
    - Password is hashed using bcrypt
    - User has both project owner and seeker roles
*/

-- Create admin user
INSERT INTO auth.users (
  instance_id,
  id,
  aud,
  role,
  email,
  encrypted_password,
  email_confirmed_at,
  recovery_sent_at,
  last_sign_in_at,
  raw_app_meta_data,
  raw_user_meta_data,
  created_at,
  updated_at,
  confirmation_token,
  email_change,
  email_change_token_new,
  recovery_token
) VALUES
  (
    '00000000-0000-0000-0000-000000000000',
    'fd3d4c8e-9f8d-4ec2-b361-85574c8df4bf',
    'authenticated',
    'authenticated',
    'test.admin@example.com',
    crypt('admin123', gen_salt('bf')),
    current_timestamp,
    current_timestamp,
    current_timestamp,
    '{"provider": "email", "providers": ["email"]}',
    '{"role": ["project_owner", "project_seeker"]}',
    current_timestamp,
    current_timestamp,
    '',
    '',
    '',
    ''
  );

-- Create both profiles for admin
INSERT INTO public.profiles (
  id,
  user_id,
  role,
  full_name,
  city,
  bio,
  skills,
  experience_level,
  company_name,
  collaboration_type,
  created_at,
  updated_at
) VALUES
  -- Project Owner Profile
  (
    'a1b2c3d4-e5f6-4789-8i9j-0k1l2m3n4o5p',
    'fd3d4c8e-9f8d-4ec2-b361-85574c8df4bf',
    'project_owner',
    'Admin Test',
    'Paris',
    'Compte administrateur pour les tests.',
    ARRAY['Management', 'Innovation', 'Entrepreneuriat'],
    '5+ ans',
    'Test Company',
    'Temps plein',
    current_timestamp,
    current_timestamp
  ),
  -- Project Seeker Profile
  (
    'b2c3d4e5-f6g7-5678-9j0k-1l2m3n4o5p6q',
    'fd3d4c8e-9f8d-4ec2-b361-85574c8df4bf',
    'project_seeker',
    'Admin Test',
    'Paris',
    'Compte administrateur pour les tests.',
    ARRAY['JavaScript', 'React', 'Node.js'],
    '3+ ans',
    'Test Company',
    'Freelance',
    current_timestamp,
    current_timestamp
  );