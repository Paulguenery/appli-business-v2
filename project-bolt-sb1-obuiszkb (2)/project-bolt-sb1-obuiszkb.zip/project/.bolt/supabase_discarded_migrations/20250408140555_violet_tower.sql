-- Add more French cities
INSERT INTO cities (name, department, postal_code, latitude, longitude)
VALUES 
  -- Major cities with unique postal codes to avoid conflicts
  ('Paris', 'Paris', '75003', 48.8566, 2.3522),
  ('Lyon', 'Rhône', '69003', 45.7578, 4.8320),
  ('Marseille', 'Bouches-du-Rhône', '13003', 43.2965, 5.3698),
  ('Bordeaux', 'Gironde', '33002', 44.8378, -0.5792),
  ('Lille', 'Nord', '59002', 50.6292, 3.0573),
  ('Toulouse', 'Haute-Garonne', '31002', 43.6047, 1.4442),
  ('Nantes', 'Loire-Atlantique', '44002', 47.2184, -1.5536),
  ('Strasbourg', 'Bas-Rhin', '67002', 48.5734, 7.7521),
  ('Montpellier', 'Hérault', '34002', 43.6108, 3.8767),
  ('Rennes', 'Ille-et-Vilaine', '35002', 48.1173, -1.6778),
  
  -- Medium-sized cities
  ('Grenoble', 'Isère', '38002', 45.1885, 5.7245),
  ('Angers', 'Maine-et-Loire', '49002', 47.4784, -0.5632),
  ('Dijon', 'Côte-d''Or', '21002', 47.3220, 5.0415),
  ('Le Havre', 'Seine-Maritime', '76602', 49.4944, 0.1079),
  ('Saint-Étienne', 'Loire', '42002', 45.4397, 4.3872),
  ('Toulon', 'Var', '83002', 43.1242, 5.9280),
  ('Annecy', 'Haute-Savoie', '74002', 45.8992, 6.1294),
  ('Biarritz', 'Pyrénées-Atlantiques', '64202', 43.4832, -1.5586),
  ('Cannes', 'Alpes-Maritimes', '06402', 43.5528, 7.0174),
  ('La Rochelle', 'Charente-Maritime', '17002', 46.1591, -1.1520)
ON CONFLICT (postal_code, name) DO NOTHING;

-- Add sample profiles and projects in these cities
DO $$
DECLARE
  city_record RECORD;
  new_user_id uuid;
  new_profile_id uuid;
  sectors text[];
  skills text[];
  user_types text[] := ARRAY['project_owner', 'project_seeker', 'investor'];
  user_type text;
  city_count integer := 0;
  project_id uuid;
  project_title text;
  project_description text;
  project_category text;
  collaboration_type text;
  experience_level text;
  unique_email text;
BEGIN
  -- Loop through cities to create profiles in different locations
  FOR city_record IN SELECT * FROM cities LIMIT 20 LOOP
    city_count := city_count + 1;
    
    -- Create only 1 profile per city to avoid too many
    -- Alternate between user types
    user_type := user_types[(city_count % 3) + 1];
    
    -- Generate sectors based on user type
    IF user_type = 'project_owner' THEN
      sectors := ARRAY['🧠 Technologie & Numérique', '📱 Communication & Marketing', '🛒 Commerce & Distribution'];
      skills := ARRAY['Gestion de projet', 'Business Development', 'Marketing', 'UI/UX Design'];
    ELSIF user_type = 'project_seeker' THEN
      sectors := ARRAY['🧠 Technologie & Numérique', '🎨 Création & Culture', '📱 Communication & Marketing'];
      skills := ARRAY['Développement web', 'UI/UX Design', 'React', 'Node.js'];
    ELSE -- investor
      sectors := ARRAY['🧠 Technologie & Numérique', '💼 Business & Finances', '🏥 Santé & Bien-être'];
      skills := ARRAY['Analyse financière', 'Due Diligence', 'Stratégie'];
    END IF;
    
    -- Create a unique email to avoid conflicts
    unique_email := 'user_' || city_record.postal_code || '_' || city_count || '@example.com';
    
    -- Create user
    new_user_id := gen_random_uuid();
    
    -- Insert into auth.users with a try-catch block to handle potential duplicates
    BEGIN
      INSERT INTO auth.users (id, email)
      VALUES (new_user_id, unique_email);
      
      -- Create profile
      new_profile_id := gen_random_uuid();
      INSERT INTO profiles (
        id, 
        user_id, 
        role, 
        user_type, 
        full_name, 
        city, 
        bio, 
        skills, 
        sectors,
        experience_level, 
        availability, 
        latitude, 
        longitude, 
        is_verified
      ) VALUES (
        new_profile_id,
        new_user_id,
        user_type,
        user_type,
        'Utilisateur ' || city_record.name,
        city_record.name,
        'Professionnel basé à ' || city_record.name || ' dans le secteur ' || sectors[1],
        skills,
        sectors,
        CASE WHEN city_count % 3 = 0 THEN 'senior' WHEN city_count % 3 = 1 THEN 'intermediaire' ELSE 'junior' END,
        CASE WHEN city_count % 2 = 0 THEN 'Temps plein' ELSE 'Temps partiel' END,
        city_record.latitude,
        city_record.longitude,
        city_count % 5 = 0 -- Every 5th profile is verified
      );
      
      -- Create a project if user is project owner
      IF user_type = 'project_owner' THEN
        -- Generate project details
        project_id := gen_random_uuid();
        
        -- Vary project titles and descriptions based on city
        IF city_count % 5 = 0 THEN
          project_title := 'Startup Tech à ' || city_record.name;
          project_description := 'Développement d''une application innovante dans le domaine de la tech à ' || city_record.name;
          project_category := '🧠 Technologie & Numérique';
        ELSIF city_count % 5 = 1 THEN
          project_title := 'E-commerce local à ' || city_record.name;
          project_description := 'Création d''une plateforme de vente en ligne pour les produits locaux de ' || city_record.name;
          project_category := '🛒 Commerce & Distribution';
        ELSIF city_count % 5 = 2 THEN
          project_title := 'Agence marketing à ' || city_record.name;
          project_description := 'Lancement d''une agence de marketing digital spécialisée dans la région de ' || city_record.name;
          project_category := '📱 Communication & Marketing';
        ELSIF city_count % 5 = 3 THEN
          project_title := 'Projet écologique à ' || city_record.name;
          project_description := 'Initiative environnementale visant à améliorer la durabilité à ' || city_record.name;
          project_category := '🌿 Écologie & Impact';
        ELSE
          project_title := 'Startup EdTech à ' || city_record.name;
          project_description := 'Développement d''une solution éducative innovante basée à ' || city_record.name;
          project_category := '📚 Éducation & Formation';
        END IF;
        
        -- Set collaboration type and experience level
        collaboration_type := CASE WHEN city_count % 2 = 0 THEN 'Temps plein' ELSE 'Temps partiel' END;
        experience_level := CASE 
          WHEN city_count % 3 = 0 THEN 'experienced' 
          WHEN city_count % 3 = 1 THEN 'beginner' 
          ELSE 'any' 
        END;
        
        -- Insert project
        INSERT INTO projects (
          id,
          owner_id,
          title,
          brief_description,
          category,
          required_skills,
          collaboration_type,
          experience_level,
          latitude,
          longitude
        ) VALUES (
          project_id,
          new_profile_id,
          project_title,
          project_description,
          project_category,
          skills,
          collaboration_type,
          experience_level,
          city_record.latitude,
          city_record.longitude
        );
      END IF;
    EXCEPTION
      WHEN others THEN
        -- Skip this user if there's an error (like duplicate email)
        CONTINUE;
    END;
  END LOOP;
END $$;