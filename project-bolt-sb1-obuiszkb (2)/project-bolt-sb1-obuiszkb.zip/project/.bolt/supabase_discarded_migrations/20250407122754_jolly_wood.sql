/*
  # Add onboarding table and related functions

  1. New Tables
    - `onboarding`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `step` (int)
      - `completed_steps` (text[])
      - `answers` (jsonb)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Functions
    - `update_onboarding_progress`: Updates onboarding progress for a user
    - `is_onboarding_completed`: Checks if a user has completed onboarding

  3. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view own onboarding" ON onboarding;
DROP POLICY IF EXISTS "Users can update own onboarding" ON onboarding;
DROP POLICY IF EXISTS "Users can insert own onboarding" ON onboarding;

-- Create onboarding table if it doesn't exist
CREATE TABLE IF NOT EXISTS onboarding (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  step int DEFAULT 1,
  completed_steps text[] DEFAULT '{}',
  answers jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE onboarding ENABLE ROW LEVEL SECURITY;

-- Create RLS Policies
CREATE POLICY "Users can view own onboarding"
  ON onboarding FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can update own onboarding"
  ON onboarding FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can insert own onboarding"
  ON onboarding FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Function to update onboarding progress
CREATE OR REPLACE FUNCTION update_onboarding_progress(
  user_uuid uuid,
  step_number int,
  step_answers jsonb
)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO onboarding (
    user_id,
    step,
    answers,
    completed_steps,
    updated_at
  )
  VALUES (
    user_uuid,
    step_number,
    step_answers,
    ARRAY[step_number::text],
    now()
  )
  ON CONFLICT (user_id) DO UPDATE
  SET
    step = step_number,
    answers = onboarding.answers || step_answers,
    completed_steps = array_append(onboarding.completed_steps, step_number::text),
    updated_at = now();
END;
$$;

-- Function to check if onboarding is completed
CREATE OR REPLACE FUNCTION is_onboarding_completed(user_uuid uuid)
RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
  completed boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM profiles
    WHERE user_id = user_uuid
    AND onboarding_completed = true
  ) INTO completed;
  
  RETURN completed;
END;
$$;

-- Grant execute permissions to authenticated users
GRANT EXECUTE ON FUNCTION update_onboarding_progress TO authenticated;
GRANT EXECUTE ON FUNCTION is_onboarding_completed TO authenticated;